//
//  Battle+CoreDataClass.swift
//  Pokedex
//
//  Created by John Lin on 2020-05-25.
//  Copyright © 2020 John Lin. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Battle)
public class Battle: NSManagedObject {

}
